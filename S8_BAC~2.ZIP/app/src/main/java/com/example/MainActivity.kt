package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.HistoryEntity
import com.example.data.UserEntity
import com.example.ui.MainViewModel
import com.example.ui.PredictionResult
import com.example.ui.theme.*
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp

class ParallelogramShape(val angle: Float = 15f) : Shape {
    override fun createOutline(
        size: Size,
        layoutDirection: LayoutDirection,
        density: androidx.compose.ui.unit.Density
    ): Outline {
        val path = Path().apply {
            moveTo(angle, 0f)
            lineTo(size.width, 0f)
            lineTo(size.width - angle, size.height)
            lineTo(0f, size.height)
            close()
        }
        return Outline.Generic(path)
    }
}

fun Modifier.cyberCorners(
    color: Color = Color(0xFF00E5FF),
    size: Dp = 10.dp,
    strokeWidth: Dp = 1.5.dp
): Modifier = this.drawBehind {
    val sizePx = size.toPx()
    val swPx = strokeWidth.toPx()
    
    // Top-Left L corner
    drawLine(
        color = color,
        start = Offset(0f, 0f),
        end = Offset(sizePx, 0f),
        strokeWidth = swPx
    )
    drawLine(
        color = color,
        start = Offset(0f, 0f),
        end = Offset(0f, sizePx),
        strokeWidth = swPx
    )

    // Bottom-Right L corner
    drawLine(
        color = color,
        start = Offset(this.size.width - sizePx, this.size.height),
        end = Offset(this.size.width, this.size.height),
        strokeWidth = swPx
    )
    drawLine(
        color = color,
        start = Offset(this.size.width, this.size.height - sizePx),
        end = Offset(this.size.width, this.size.height),
        strokeWidth = swPx
    )
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = CyberBg
                ) {
                    S8BaccaratApp()
                }
            }
        }
    }
}

@Composable
fun S8BaccaratApp() {
    val viewModel: MainViewModel = viewModel()
    val currentUser by viewModel.currentUser.collectAsState()
    val isComputing by viewModel.isComputing.collectAsState()
    val computingMessage by viewModel.computingMessage.collectAsState()

    var showApp by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBg)
    ) {
        if (!showApp || currentUser == null) {
            LandingScreen(
                viewModel = viewModel,
                onLoginSuccess = {
                    showApp = true
                }
            )
        } else {
            AppDashboardScreen(
                viewModel = viewModel,
                onLogout = {
                    showApp = false
                }
            )
        }

        // Computing Overlay Screen
        if (isComputing) {
            ComputingOverlay(message = computingMessage)
        }
    }
}

// ==================== COMPONENTS & UTIL DRAWING ====================

// Draw elegant Material 3 style smooth borders for the Elegant Dark theme
fun Modifier.cyberBorder(color: Color = Color(0xFF44474F), strokeWidth: Float = 1.2f): Modifier = this
    .border(BorderStroke(strokeWidth.dp, color), RoundedCornerShape(24.dp))
    .clip(RoundedCornerShape(24.dp))

// Glowing custom Cyber Header with S8 diamonds (octagon cut corner feel)
@Composable
fun CyberLogoHeader(scale: Float = 1.0f) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size((38 * scale).dp)
                .clip(CutCornerShape(10.dp))
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFF002A88), Color(0xFF001260))
                    )
                )
                .border(1.5.dp, CyberPrimary, CutCornerShape(10.dp))
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "S8",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = (14 * scale).sp,
                    fontFamily = FontFamily.SansSerif,
                    lineHeight = (14 * scale).sp
                )
                Text(
                    text = "✦",
                    color = CyberPrimary,
                    fontSize = (8 * scale).sp,
                    lineHeight = (8 * scale).sp
                )
            }
        }
    }
}// ==================== SCREEN 1: LANDING & LOGIN ====================
@Composable
fun LandingScreen(
    viewModel: MainViewModel,
    onLoginSuccess: () -> Unit
) {
    val loginUsername by viewModel.loginUsername.collectAsState()
    val loginPassword by viewModel.loginPassword.collectAsState()
    val loginError by viewModel.loginError.collectAsState()

    var passwordVisible by remember { mutableStateOf(false) }

    // Dynamic vertical position for scanning line animation
    val infiniteTransition = rememberInfiniteTransition(label = "scan_line")
    val scanProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "scan"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBg)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // High fidelity technical cyber grid background drawing
        Box(
            modifier = Modifier
                .fillMaxSize()
                .drawBehind {
                    val gridSpacing = 30.dp.toPx()
                    
                    // Draw horizontal lines
                    var y = 0f
                    while (y < size.height) {
                        drawLine(
                            color = Color(0xFF00E5FF).copy(alpha = 0.035f),
                            start = Offset(0f, y),
                            end = Offset(size.width, y),
                            strokeWidth = 1.dp.toPx()
                        )
                        y += gridSpacing
                    }
                    
                    // Draw vertical lines
                    var x = 0f
                    while (x < size.width) {
                        drawLine(
                            color = Color(0xFF00E5FF).copy(alpha = 0.035f),
                            start = Offset(x, 0f),
                            end = Offset(x, size.height),
                            strokeWidth = 1.dp.toPx()
                        )
                        x += gridSpacing
                    }

                    // Draw moving tech scanline
                    val lineY = size.height * scanProgress
                    drawLine(
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color(0xFF00E5FF).copy(alpha = 0.15f),
                                Color(0xFF00E5FF).copy(alpha = 0.3f),
                                Color(0xFF00E5FF).copy(alpha = 0.15f),
                                Color.Transparent
                            )
                        ),
                        start = Offset(0f, lineY),
                        end = Offset(size.width, lineY),
                        strokeWidth = 3.dp.toPx()
                    )
                }
        )

        // Glow radial highlights
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(350.dp)
                .align(Alignment.TopCenter)
                .drawBehind {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0xFF0055FF).copy(alpha = 0.12f), Color.Transparent)
                        ),
                        radius = 220.dp.toPx(),
                        center = Offset(size.width / 2f, 0f)
                    )
                }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 20.dp)
                .widthIn(max = 450.dp)
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // Tech Banner Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp))
                    .border(1.dp, CyberPrimary.copy(alpha = 0.25f), CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp))
                    .background(Color(0xFF000B1A).copy(alpha = 0.8f))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CyberLogoHeader(scale = 0.85f)
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Công Thức Baccarat",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "congthucbcrvip.com",
                        color = CyberPrimary.copy(alpha = 0.5f),
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .border(1.dp, Color(0xFF00FF88).copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                        .background(Color(0xFF002211).copy(alpha = 0.6f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0xFF00FF88))
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "ONLINE",
                        color = Color(0xFF00FF88),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            // Big Bold Branding Typography
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(2.dp),
                modifier = Modifier.padding(vertical = 10.dp)
            ) {
                Text(
                    text = "AI CALCULATOR SYSTEM",
                    color = CyberPrimary.copy(alpha = 0.7f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 4.sp
                )
                Text(
                    text = "S8 BACCARAT",
                    color = Color.White,
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    textAlign = TextAlign.Center,
                    fontFamily = FontFamily.SansSerif,
                    modifier = Modifier.drawBehind {
                        drawLine(
                            brush = Brush.horizontalGradient(
                                colors = listOf(Color.Transparent, CyberPrimary, Color.Transparent)
                            ),
                            start = Offset(size.width * 0.15f, size.height + 4.dp.toPx()),
                            end = Offset(size.width * 0.85f, size.height + 4.dp.toPx()),
                            strokeWidth = 2.dp.toPx()
                        )
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "PREDICTION CORE v8.0 · SECURE SECURE",
                    color = CyberPrimary.copy(alpha = 0.45f),
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.2.sp
                )
            }

            // Trust info & badges
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .background(CyberGold.copy(alpha = 0.12f), RoundedCornerShape(6.dp))
                        .border(1.dp, CyberGold.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "CHUẨN XÁC 2026",
                        color = CyberGold,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    )
                }
                Box(
                    modifier = Modifier
                        .background(Color(0xFF002244), RoundedCornerShape(6.dp))
                        .border(1.dp, CyberPrimary.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "ĐỘC QUYỀN S8",
                        color = CyberPrimary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            // Interactive HUD Dashboard statistics
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF44474F).copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                    .background(CyberSurface.copy(alpha = 0.85f))
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("98.8%", color = Color(0xFF4499FF), fontSize = 18.sp, fontWeight = FontWeight.Black)
                    Text("ĐỘ CHÍNH XÁC", color = TextSecondary.copy(alpha = 0.5f), fontSize = 7.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                }
                Box(modifier = Modifier.width(1.dp).height(24.dp).background(Color(0xFF44474F).copy(alpha = 0.5f)))
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("40+", color = Color(0xFF00FF88), fontSize = 18.sp, fontWeight = FontWeight.Black)
                    Text("SỐ BÀN", color = TextSecondary.copy(alpha = 0.5f), fontSize = 7.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                }
                Box(modifier = Modifier.width(1.dp).height(24.dp).background(Color(0xFF44474F).copy(alpha = 0.5f)))
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("SEXY/DG/MT", color = CyberAccent, fontSize = 11.sp, fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text("SẢNH HỖ TRỢ", color = TextSecondary.copy(alpha = 0.5f), fontSize = 7.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                }
            }

            // Main Login octagon card structure
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(CutCornerShape(16.dp))
                    .background(CyberCardBg.copy(alpha = 0.9f))
                    .border(1.2.dp, Color(0xFF44474F).copy(alpha = 0.6f), CutCornerShape(16.dp))
                    .cyberCorners(color = CyberPrimary)
                    .padding(20.dp)
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Header of Form
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .drawBehind {
                                drawLine(
                                    color = Color(0xFF00E5FF).copy(alpha = 0.15f),
                                    start = Offset(0f, size.height + 4.dp.toPx()),
                                    end = Offset(size.width, size.height + 4.dp.toPx()),
                                    strokeWidth = 1.dp.toPx()
                                )
                            }
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CutCornerShape(6.dp))
                                .border(1.dp, CyberPrimary, CutCornerShape(6.dp))
                                .background(Color(0xFF001A3F))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = CyberPrimary,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                        Text(
                            text = "ĐĂNG NHẬP THÀNH VIÊN",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = "SYS_AUTH_v8",
                            color = CyberPrimary.copy(alpha = 0.4f),
                            fontSize = 7.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Username text field
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "TÊN TÀI KHOẢN",
                            color = CyberPrimary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .background(CyberBg, RoundedCornerShape(8.dp))
                                .border(1.dp, Color(0xFF44474F).copy(alpha = 0.8f), RoundedCornerShape(8.dp))
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = CyberPrimary.copy(alpha = 0.7f),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            TextField(
                                value = loginUsername,
                                onValueChange = { viewModel.loginUsername.value = it },
                                placeholder = { Text("Nhập tài khoản...", color = TextSecondary.copy(alpha = 0.4f), fontSize = 13.sp) },
                                singleLine = true,
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    disabledContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent
                                ),
                                textStyle = TextStyle(color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Password text field
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "MẬT KHẨU BẢO MẬT",
                            color = CyberPrimary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .background(CyberBg, RoundedCornerShape(8.dp))
                                .border(1.dp, Color(0xFF44474F).copy(alpha = 0.8f), RoundedCornerShape(8.dp))
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = CyberPrimary.copy(alpha = 0.7f),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            TextField(
                                value = loginPassword,
                                onValueChange = { viewModel.loginPassword.value = it },
                                placeholder = { Text("Nhập mật khẩu...", color = TextSecondary.copy(alpha = 0.4f), fontSize = 13.sp) },
                                singleLine = true,
                                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                trailingIcon = {
                                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                        Icon(
                                            imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                            contentDescription = null,
                                            tint = CyberPrimary.copy(alpha = 0.7f)
                                        )
                                    }
                                },
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    disabledContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent
                                ),
                                textStyle = TextStyle(color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Display errors
                    if (loginError != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CyberAccent.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                .border(1.dp, CyberAccent.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = loginError ?: "",
                                color = CyberAccent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Login Button (Classic Cyber slant/shape representation)
                    Button(
                        onClick = {
                            viewModel.doLogin(onSuccess = onLoginSuccess)
                        },
                        shape = CutCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Login,
                                contentDescription = null,
                                tint = Color(0xFF001235),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "KẾT NỐI HỆ THỐNG",
                                color = Color(0xFF001235),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.5.sp
                            )
                        }
                    }

                    Text(
                        text = "Chưa có tài khoản? Liên hệ quản trị viên để được cấp khóa truy cập.",
                        color = TextSecondary.copy(alpha = 0.5f),
                        fontSize = 10.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 14.sp,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // App Footer branding elements
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(top = 10.dp, bottom = 20.dp)
            ) {
                Text(
                    text = "S8 BACCARAT AI ENGINE",
                    color = CyberPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "Dẫn Đầu Công Nghệ · Độc Quyền Chiến Thắng",
                    color = CyberPrimary.copy(alpha = 0.45f),
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ==================== SCREEN 2: MAIN DASHBOARD ====================
@Composable
fun AppDashboardScreen(
    viewModel: MainViewModel,
    onLogout: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    var currentTab by remember { mutableStateOf("calc") }
    var isAdminModalOpen by remember { mutableStateOf(false) }

    val context = LocalContext.current

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBg),
        bottomBar = {
            // Elegant M3 Bottom Nav
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(76.dp)
                    .background(CyberBg)
                    .drawBehind {
                        // Top divider border matching the theme
                        drawLine(
                            color = Color(0xFF44474F).copy(alpha = 0.35f),
                            start = Offset(0f, 0f),
                            end = Offset(size.width, 0f),
                            strokeWidth = 1.dp.toPx()
                        )
                    },
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Tab 1 Button
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple()
                        ) { currentTab = "calc" }
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(if (currentTab == "calc") CyberPrimary else Color.Transparent)
                                .padding(horizontal = 20.dp, vertical = 5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Calculate,
                                contentDescription = null,
                                tint = if (currentTab == "calc") Color(0xFF381E72) else TextSecondary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "TÍNH TOÁN",
                            color = if (currentTab == "calc") TextPrimary else TextSecondary.copy(alpha = 0.6f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                // Tab 2 Button
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple()
                        ) { currentTab = "history" }
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(if (currentTab == "history") CyberPrimary else Color.Transparent)
                                .padding(horizontal = 20.dp, vertical = 5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = null,
                                tint = if (currentTab == "history") Color(0xFF381E72) else TextSecondary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "LỊCH SỬ",
                            color = if (currentTab == "history") TextPrimary else TextSecondary.copy(alpha = 0.6f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(CyberBg)
                .padding(innerPadding)
        ) {
            // High-fidelity App Header (Elegant Dark top bar)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(CyberBg)
                    .drawBehind {
                        // Clean, minimal theme border at the bottom
                        drawLine(
                            color = Color(0xFF44474F).copy(alpha = 0.35f),
                            start = Offset(0f, size.height),
                            end = Offset(size.width, size.height),
                            strokeWidth = 1.dp.toPx()
                        )
                    }
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Header Logo
                CyberLogoHeader(scale = 0.85f)
                Spacer(modifier = Modifier.width(8.dp))

                // User Info Group
                Column(
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = (currentUser?.username ?: "VIP").uppercase(),
                        color = if (currentUser?.isSystemAdmin == true) CyberGold else TextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (currentUser?.isSystemAdmin == true) "👑 QUẢN TRỊ VIÊN" else "VIP MEMBER",
                        color = if (currentUser?.isSystemAdmin == true) CyberGold else CyberPrimary,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Middle HUD display
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(horizontal = 6.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(26.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(
                                1.dp,
                                if (currentUser?.isSystemAdmin == true) CyberGold.copy(alpha = 0.5f) else CyberPrimary.copy(
                                    alpha = 0.5f
                                ),
                                RoundedCornerShape(8.dp)
                            )
                    ) {
                        Icon(
                            imageVector = if (currentUser?.isSystemAdmin == true) Icons.Default.Star else Icons.Default.Person,
                            contentDescription = null,
                            tint = if (currentUser?.isSystemAdmin == true) CyberGold else CyberPrimary,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }

                // QL TK (Admin actions button)
                if (currentUser?.isSystemAdmin == true) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, CyberGold.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .background(CyberSurface)
                            .clickable {
                                isAdminModalOpen = true
                            }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ManageAccounts,
                                contentDescription = null,
                                tint = CyberGold,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "QL TK",
                                color = CyberGold,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                // XUẤT (Logout) Button with elegant styling
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.dp, CyberAccent.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                        .background(CyberSurface)
                        .clickable {
                            viewModel.doLogout(onSuccess = onLogout)
                            Toast
                                .makeText(context, "Đã đăng xuất thành công!", Toast.LENGTH_SHORT)
                                .show()
                        }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Logout,
                            contentDescription = null,
                            tint = Color(0xFFFF7070),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "XUẤT",
                            color = Color(0xFFFF7070),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Tab Pane Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (currentTab == "calc") {
                    CalculationTabScreen(viewModel = viewModel)
                } else {
                    HistoryTabScreen(viewModel = viewModel)
                }
            }
        }
    }

    // Admin accounts modal dialog
    if (isAdminModalOpen) {
        AdminAccountsModal(
            viewModel = viewModel,
            onClose = { isAdminModalOpen = false }
        )
    }
}

// ==================== TAB 1: CALCULATION PANEL ====================
@Composable
fun CalculationTabScreen(viewModel: MainViewModel) {
    val selectedLobby by viewModel.lobby.collectAsState()
    val selectedTable by viewModel.tableNum.collectAsState()
    val playerScore by viewModel.playerScore.collectAsState()
    val bankerScore by viewModel.bankerScore.collectAsState()
    val predictionResult by viewModel.predictionResult.collectAsState()

    val pCount by viewModel.pCount.collectAsState()
    val bCount by viewModel.bCount.collectAsState()
    val tCount by viewModel.tCount.collectAsState()

    val sigFreqP by viewModel.sigFreqP.collectAsState()
    val sigFreqT by viewModel.sigFreqT.collectAsState()
    val sigFreqB by viewModel.sigFreqB.collectAsState()

    val systemClock by viewModel.systemClock.collectAsState()
    val waveformHeights by viewModel.waveformHeights.collectAsState()

    var showLobbyMenu by remember { mutableStateOf(false) }
    var showTableMenu by remember { mutableStateOf(false) }

    val lobbies = listOf("SẢNH - SEXY", "SẢNH - DG", "SẢNH - MT")
    val tables = (1..20).map { "C" + String.format("%02d", it) } + (1..20).map { "BÀN $it" }

    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Main Input Panel
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(CutCornerShape(12.dp))
                .border(1.dp, Color(0xFF44474F).copy(alpha = 0.5f), CutCornerShape(12.dp))
                .background(CyberCardBg)
                .cyberCorners(color = CyberPrimary)
                .padding(12.dp)
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Section Title Row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .drawBehind {
                            drawLine(
                                color = CyberPrimary.copy(alpha = 0.15f),
                                start = Offset(0f, size.height + 4.dp.toPx()),
                                end = Offset(size.width, size.height + 4.dp.toPx()),
                                strokeWidth = 1.dp.toPx()
                            )
                        }
                ) {
                    Icon(
                        imageVector = Icons.Default.Calculate,
                        contentDescription = null,
                        tint = CyberPrimary,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = "NHẬP DỮ LIỆU",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF002350).copy(alpha = 0.6f), RoundedCornerShape(2.dp))
                            .border(1.dp, CyberPrimary.copy(alpha = 0.3f), RoundedCornerShape(2.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "AI ENGINE ACTIVE",
                            color = CyberPrimary,
                            fontSize = 7.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                // Lobbies & Tables selector Dropdowns
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Lobby Select Dropdown
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberBg)
                            .border(
                                width = 1.dp,
                                color = Color(0xFF44474F).copy(alpha = 0.7f),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { showLobbyMenu = true }
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Sảnh",
                                color = CyberPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = selectedLobby,
                                color = TextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Center
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                tint = CyberPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = showLobbyMenu,
                            onDismissRequest = { showLobbyMenu = false },
                            modifier = Modifier.background(CyberSurface)
                        ) {
                            lobbies.forEach { lobbyItem ->
                                DropdownMenuItem(
                                    text = { Text(lobbyItem, color = TextPrimary, fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        viewModel.setLobby(lobbyItem)
                                        showLobbyMenu = false
                                    }
                                )
                            }
                        }
                    }

                    // Table Select Dropdown
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberBg)
                            .border(
                                width = 1.dp,
                                color = Color(0xFF44474F).copy(alpha = 0.7f),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { showTableMenu = true }
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Bàn",
                                color = CyberPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = selectedTable,
                                color = TextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Center
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                tint = CyberPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = showTableMenu,
                            onDismissRequest = { showTableMenu = false },
                            modifier = Modifier
                                .background(CyberSurface)
                                .height(250.dp)
                        ) {
                            tables.forEach { tableItem ->
                                DropdownMenuItem(
                                    text = { Text(tableItem, color = TextPrimary, fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        viewModel.setTableNum(tableItem)
                                        showTableMenu = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Selected Info Display Boxes (Thuyết minh 1 & 2)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Lobby Display Card
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, CyberPrimary.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                            .drawBehind {
                                drawLine(
                                    color = CyberPrimary,
                                    start = Offset(0f, 0f),
                                    end = Offset(0f, size.height),
                                    strokeWidth = 3.5.dp.toPx()
                                )
                            }
                            .background(Color(0xFF000F26).copy(alpha = 0.9f))
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = selectedLobby,
                            color = CyberPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(text = "Sảnh đang chọn", color = CyberPrimary.copy(alpha = 0.45f), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }

                    // Table Display Card
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, CyberPrimary.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                            .drawBehind {
                                drawLine(
                                    color = CyberPrimary,
                                    start = Offset(0f, 0f),
                                    end = Offset(0f, size.height),
                                    strokeWidth = 3.5.dp.toPx()
                                )
                            }
                            .background(Color(0xFF000F26).copy(alpha = 0.9f))
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = selectedTable,
                            color = CyberPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(text = "Bàn đang chọn", color = CyberPrimary.copy(alpha = 0.45f), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // PLAYER & BANKER & COEFF input boxes (Three side-by-side)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // 1. PLAYER SCORE INPUT
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberBg)
                            .border(1.dp, Color(0xFF44474F).copy(alpha = 0.7f), RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "PLAYER",
                                color = Color(0xFF4499FF),
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Black
                            )
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = Color(0xFF4499FF),
                                modifier = Modifier.size(10.dp)
                            )
                        }

                        TextField(
                            value = playerScore,
                            onValueChange = { value ->
                                if (value.isEmpty() || (value.toIntOrNull() != null && value.toInt() in 0..9)) {
                                    viewModel.playerScore.value = value
                                }
                            },
                            placeholder = { Text("0–9", color = Color(0xFF4499FF).copy(alpha = 0.25f), fontSize = 15.sp) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                disabledContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            textStyle = TextStyle(
                                color = Color(0xFF00E5FF),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Text(
                            text = "NHÀ CON",
                            color = Color(0xFF4499FF),
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    }

                    // 2. BANKER SCORE INPUT
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberBg)
                            .border(1.dp, Color(0xFF44474F).copy(alpha = 0.7f), RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "BANKER",
                                color = Color(0xFFFF6644),
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Black
                            )
                            Icon(
                                imageVector = Icons.Default.Apartment,
                                contentDescription = null,
                                tint = Color(0xFFFF6644),
                                modifier = Modifier.size(10.dp)
                            )
                        }

                        TextField(
                            value = bankerScore,
                            onValueChange = { value ->
                                if (value.isEmpty() || (value.toIntOrNull() != null && value.toInt() in 0..9)) {
                                    viewModel.bankerScore.value = value
                                }
                            },
                            placeholder = { Text("0–9", color = Color(0xFFFF6644).copy(alpha = 0.25f), fontSize = 15.sp) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                disabledContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            textStyle = TextStyle(
                                color = Color(0xFFFF6644),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Text(
                            text = "NHÀ CÁI",
                            color = Color(0xFFFF6644),
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    }

                    // 3. FORMULA COEFFICIENT AUTO INPUT
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberBg)
                            .border(1.dp, Color(0xFF44474F).copy(alpha = 0.7f), RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "HỆ SỐ",
                                color = CyberGold,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Black
                            )
                            Icon(
                                imageVector = Icons.Default.Memory,
                                contentDescription = null,
                                tint = CyberGold,
                                modifier = Modifier.size(10.dp)
                            )
                        }

                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(64.dp)
                        ) {
                            Text(
                                text = "AUTO",
                                color = CyberGold,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center
                            )
                        }

                        Text(
                            text = "CÔNG THỨC",
                            color = CyberGold,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    }
                }

                // TÍNH TOÁN NGAY Button - Slanted Parallelogram shape
                Button(
                    onClick = {
                        val pVal = playerScore.trim().toIntOrNull()
                        val bVal = bankerScore.trim().toIntOrNull()
                        if (pVal == null || bVal == null) {
                            Toast.makeText(context, "⚠ Vui lòng nhập điểm Nhà Con và Nhà Cái hợp lệ!", Toast.LENGTH_SHORT).show()
                        } else {
                            viewModel.calculate()
                        }
                    },
                    shape = ParallelogramShape(20f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF001A3F)
                    ),
                    border = BorderStroke(1.5.dp, CyberPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "TÍNH TOÁN NGAY",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.5.sp
                        )
                    }
                }

                // Probability Display Box Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(CyberSurface)
                        .border(1.dp, Color(0xFF44474F).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "XÁC SUẤT DỰ ĐOÁN VÁN SAU",
                            color = TextSecondary.copy(alpha = 0.7f),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Progress bars
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            val pAnimate by animateFloatAsState(
                                targetValue = (predictionResult?.p?.toFloat() ?: 0f) / 100f,
                                animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing)
                            )
                            val tAnimate by animateFloatAsState(
                                targetValue = (predictionResult?.t?.toFloat() ?: 0f) / 100f,
                                animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing)
                            )
                            val bAnimate by animateFloatAsState(
                                targetValue = (predictionResult?.b?.toFloat() ?: 0f) / 100f,
                                animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing)
                            )

                            // 1. NHÀ CON
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "NHÀ CON",
                                    color = Color(0xFF4499FF),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(64.dp)
                                )
                                LinearProgressIndicator(
                                    progress = { pAnimate },
                                    color = Color(0xFF4499FF),
                                    trackColor = CyberBg,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (predictionResult != null) "${predictionResult?.p}%" else "—",
                                    color = Color(0xFF4499FF),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.width(40.dp),
                                    textAlign = TextAlign.End
                                )
                            }

                            // 2. HÒA
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "HÒA",
                                    color = CyberSuccess,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(64.dp)
                                )
                                LinearProgressIndicator(
                                    progress = { tAnimate },
                                    color = CyberSuccess,
                                    trackColor = CyberBg,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (predictionResult != null) "${predictionResult?.t}%" else "—",
                                    color = CyberSuccess,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.width(40.dp),
                                    textAlign = TextAlign.End
                                )
                            }

                            // 3. NHÀ CÁI
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "NHÀ CÁI",
                                    color = CyberAccent,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(64.dp)
                                )
                                LinearProgressIndicator(
                                    progress = { bAnimate },
                                    color = CyberAccent,
                                    trackColor = CyberBg,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (predictionResult != null) "${predictionResult?.b}%" else "—",
                                    color = CyberAccent,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.width(40.dp),
                                    textAlign = TextAlign.End
                                )
                            }
                        }

                        // Winning prediction crown
                        HorizontalDivider(color = Color(0xFF44474F).copy(alpha = 0.5f), modifier = Modifier.fillMaxWidth())

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            Text(
                                text = "KẾT QUẢ DỰ ĐOÁN",
                                color = TextSecondary.copy(alpha = 0.5f),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            if (predictionResult != null) {
                                val textCol = when (predictionResult?.result) {
                                    "NHÀ CON" -> Color(0xFF4499FF)
                                    "NHÀ CÁI" -> CyberAccent
                                    else -> CyberSuccess
                                }
                                val bgCol = textCol.copy(alpha = 0.12f)
                                val borderCol = textCol.copy(alpha = 0.4f)

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(bgCol)
                                        .border(1.dp, borderCol, RoundedCornerShape(8.dp))
                                        .padding(horizontal = 16.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "🏆 ${predictionResult?.result}",
                                        color = textCol,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 1.sp
                                    )
                                }
                            } else {
                                Text(
                                    text = "— CHƯA TÍNH —",
                                    color = TextSecondary.copy(alpha = 0.4f),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // AI Signal Monitor Panel
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(CyberSurface)
                .border(1.dp, Color(0xFF44474F).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0xFF00FF88))
                    )
                    Text(
                        text = "AI · SIGNAL MONITOR",
                        color = TextSecondary.copy(alpha = 0.7f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF00FF88).copy(alpha = 0.15f))
                            .border(1.dp, Color(0xFF00FF88).copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "LIVE",
                            color = Color(0xFF00FF88),
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp
                        )
                    }
                }

                // Dynamic pulsing visual waveform
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(55.dp)
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    waveformHeights.forEachIndexed { index, height ->
                        val animHeight by animateFloatAsState(
                            targetValue = height,
                            animationSpec = spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessLow)
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(animHeight)
                                .clip(RoundedCornerShape(topStart = 2.dp, topEnd = 2.dp))
                                .background(
                                    brush = Brush.verticalGradient(
                                        colors = if (index % 3 == 0) {
                                            listOf(Color(0xFF4499FF), Color(0xFF001F8A))
                                        } else if (index % 3 == 1) {
                                            listOf(Color(0xFF00CCFF), Color(0xFF003A88))
                                        } else {
                                            listOf(CyberPrimary, Color(0xFF1A6BFF))
                                        }
                                    )
                                )
                        )
                    }
                }

                HorizontalDivider(color = Color(0xFF44474F).copy(alpha = 0.5f), modifier = Modifier.fillMaxWidth().padding(top = 8.dp))

                // Frequencies Row (synchronized with calculated result probabilities)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("NHÀ CON", color = TextSecondary.copy(alpha = 0.5f), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Text(sigFreqP, color = Color(0xFF4499FF), fontSize = 13.sp, fontWeight = FontWeight.Black)
                    }
                    Box(modifier = Modifier.width(1.dp).height(26.dp).background(Color(0xFF44474F).copy(alpha = 0.5f)))
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("HÒA", color = TextSecondary.copy(alpha = 0.5f), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Text(sigFreqT, color = CyberSuccess, fontSize = 13.sp, fontWeight = FontWeight.Black)
                    }
                    Box(modifier = Modifier.width(1.dp).height(26.dp).background(Color(0xFF44474F).copy(alpha = 0.5f)))
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("NHÀ CÁI", color = TextSecondary.copy(alpha = 0.5f), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Text(sigFreqB, color = CyberAccent, fontSize = 13.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }

        // Live stats panel (showing counts of prediction outcomes)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(CyberSurface)
                .border(1.dp, Color(0xFF44474F).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$pCount", color = Color(0xFF4499FF), fontSize = 20.sp, fontWeight = FontWeight.Black)
                Text("CON THẮNG", color = TextSecondary.copy(alpha = 0.5f), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
            Box(modifier = Modifier.width(1.dp).height(24.dp).background(Color(0xFF44474F).copy(alpha = 0.5f)))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$tCount", color = CyberSuccess, fontSize = 20.sp, fontWeight = FontWeight.Black)
                Text("HÒA THẮNG", color = TextSecondary.copy(alpha = 0.5f), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
            Box(modifier = Modifier.width(1.dp).height(24.dp).background(Color(0xFF44474F).copy(alpha = 0.5f)))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$bCount", color = CyberAccent, fontSize = 20.sp, fontWeight = FontWeight.Black)
                Text("CÁI THẮNG", color = TextSecondary.copy(alpha = 0.5f), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }

        // System bottom telemetry status bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(CyberSurface)
                .border(1.dp, Color(0xFF44474F).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .padding(vertical = 10.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            // Status active
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.weight(1f)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    Box(modifier = Modifier.size(6.dp).clip(RoundedCornerShape(50)).background(Color(0xFF00FF88)))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("STATUS", color = TextSecondary.copy(alpha = 0.5f), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
                Text("ACTIVE", color = Color(0xFF00FF88), fontSize = 10.sp, fontWeight = FontWeight.Black)
            }
            Box(modifier = Modifier.width(1.dp).height(18.dp).background(Color(0xFF44474F).copy(alpha = 0.5f)))

            // Realtime Clock
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.weight(1f)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    Icon(imageVector = Icons.Default.Schedule, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(9.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("GIỜ HIỆN TẠI", color = TextSecondary.copy(alpha = 0.5f), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
                Text(systemClock, color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
            }
            Box(modifier = Modifier.width(1.dp).height(18.dp).background(Color(0xFF44474F).copy(alpha = 0.5f)))

            // Engine Version
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.weight(1f)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    Icon(imageVector = Icons.Default.Memory, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(9.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ENGINE", color = TextSecondary.copy(alpha = 0.5f), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
                Text("S8 v8.0", color = TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Black)
            }
            Box(modifier = Modifier.width(1.dp).height(18.dp).background(Color(0xFF44474F).copy(alpha = 0.5f)))

            // Security Encryption
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.weight(1f)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(9.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("BẢO MẬT", color = TextSecondary.copy(alpha = 0.5f), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
                Text("ON", color = Color(0xFF00FF88), fontSize = 10.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

// ==================== TAB 2: HISTORY LIST PANEL ====================
@Composable
fun HistoryTabScreen(viewModel: MainViewModel) {
    val historyList by viewModel.historyList.collectAsState()
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(CyberSurface)
                .border(1.dp, Color(0xFF44474F), RoundedCornerShape(16.dp))
                .padding(12.dp)
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Title & Clear All Row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = CyberPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LỊCH SỬ TÍNH TOÁN",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF2C1616))
                            .border(1.dp, Color(0xFFC83232).copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                            .clickable {
                                if (historyList.isNotEmpty()) {
                                    viewModel.clearHistory()
                                    Toast
                                        .makeText(context, "Đã xoá lịch sử tính toán!", Toast.LENGTH_SHORT)
                                        .show()
                                }
                            }
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = null,
                                tint = Color(0xFFFF8080),
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Xoá",
                                color = Color(0xFFFF8080),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                HorizontalDivider(color = Color(0xFF44474F).copy(alpha = 0.5f), modifier = Modifier.fillMaxWidth())

                // Table Headers
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(CyberBg)
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "TAY",
                        color = TextSecondary.copy(alpha = 0.7f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f),
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        "NHÀ CON",
                        color = TextSecondary.copy(alpha = 0.7f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1.2f),
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        "NHÀ CÁI",
                        color = TextSecondary.copy(alpha = 0.7f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1.2f),
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        "TỔNG ĐIỂM",
                        color = TextSecondary.copy(alpha = 0.7f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1.3f),
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        "KẾT QUẢ",
                        color = TextSecondary.copy(alpha = 0.7f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1.8f),
                        letterSpacing = 0.5.sp
                    )
                }

                // List Items
                if (historyList.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 48.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Inbox,
                            contentDescription = null,
                            tint = TextSecondary.copy(alpha = 0.3f),
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Chưa có dữ liệu. Hãy nhập và tính toán.",
                            color = TextSecondary.copy(alpha = 0.5f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().heightIn(max = 450.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        itemsIndexed(historyList) { index, item ->
                            val tayIndex = historyList.size - index
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(CyberBg)
                                    .border(
                                        width = 1.dp,
                                        color = Color(0xFF44474F).copy(alpha = 0.5f),
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .padding(vertical = 10.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Hand #
                                Text(
                                    text = "#$tayIndex",
                                    color = TextSecondary.copy(alpha = 0.6f),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.weight(1f)
                                )

                                // Player Score
                                Text(
                                    text = "${item.playerScore}",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.weight(1.2f)
                                )

                                // Banker Score
                                Text(
                                    text = "${item.bankerScore}",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.weight(1.2f)
                                )

                                // Total Score (Random factors * points)
                                Text(
                                    text = "${item.totalScore}",
                                    color = CyberPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.weight(1.3f)
                                )

                                // Predicted Outcome
                                val textCol = when (item.predictedResult) {
                                    "NHÀ CON" -> Color(0xFF4499FF)
                                    "NHÀ CÁI" -> CyberAccent
                                    else -> CyberSuccess
                                }
                                Text(
                                    text = item.predictedResult,
                                    color = textCol,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.weight(1.8f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==================== COMPUTING LOADING OVERLAY ====================
@Composable
fun ComputingOverlay(message: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "cyber_computing")
    
    // 1. Clockwise Rotation
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // 2. Counter-Clockwise Rotation
    val counterRotationAngle by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "counter_rotation"
    )

    // 3. Pulsating Opacity for AI icon
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ai_pulse"
    )

    // 4. Vertical Scanline Offset
    val scanlineOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "scanline_movement"
    )

    Dialog(onDismissRequest = {}) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF010610).copy(alpha = 0.95f))
                .drawBehind {
                    // Scanning line effect
                    val y = size.height * scanlineOffset
                    drawLine(
                        color = CyberPrimary.copy(alpha = 0.25f),
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = 2.dp.toPx()
                    )
                    // Glow around scanline
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                CyberPrimary.copy(alpha = 0.05f),
                                Color.Transparent
                            ),
                            startY = y - 30.dp.toPx(),
                            endY = y + 30.dp.toPx()
                        ),
                        topLeft = Offset(0f, y - 30.dp.toPx()),
                        size = androidx.compose.ui.geometry.Size(size.width, 60.dp.toPx())
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp),
                modifier = Modifier
                    .width(300.dp)
                    .clip(CutCornerShape(16.dp))
                    .background(Color(0xFF010E23).copy(alpha = 0.85f))
                    .border(1.5.dp, CyberPrimary.copy(alpha = 0.6f), CutCornerShape(16.dp))
                    .cyberCorners(color = CyberPrimary)
                    .padding(24.dp)
            ) {
                // Dual spinning rings with blinking AI icon
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(100.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .drawBehind {
                                // Outer cyan ring rotating clockwise
                                drawArc(
                                    color = CyberPrimary,
                                    startAngle = rotationAngle,
                                    sweepAngle = 280f,
                                    useCenter = false,
                                    style = androidx.compose.ui.graphics.drawscope.Stroke(
                                        width = 3.5.dp.toPx(),
                                        cap = androidx.compose.ui.graphics.StrokeCap.Round
                                    )
                                )
                                // Inner deep blue ring rotating counter-clockwise
                                drawArc(
                                    color = Color(0xFF4499FF),
                                    startAngle = counterRotationAngle,
                                    sweepAngle = 180f,
                                    useCenter = false,
                                    style = androidx.compose.ui.graphics.drawscope.Stroke(
                                        width = 2.dp.toPx(),
                                        cap = androidx.compose.ui.graphics.StrokeCap.Round
                                    )
                                )
                            }
                    )
                    Icon(
                        imageVector = Icons.Default.Memory,
                        contentDescription = null,
                        tint = CyberPrimary,
                        modifier = Modifier
                            .size(32.dp)
                            .graphicsLayer(alpha = pulseAlpha)
                    )
                }

                // Cyber separator lines
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.width(180.dp)
                ) {
                    repeat(3) { index ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(1f - (index * 0.15f))
                                .height(2.5.dp)
                                .background(
                                    brush = Brush.horizontalGradient(
                                        colors = listOf(Color.Transparent, CyberPrimary.copy(alpha = 0.8f), Color.Transparent)
                                    )
                                )
                        )
                    }
                }

                // Loading Text Message
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "ĐANG PHÂN TÍCH DỮ LIỆU",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp,
                        textAlign = TextAlign.Center
                    )

                    // Sub-status flashing
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = message.uppercase(),
                            color = CyberPrimary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

// ==================== ADMIN PANEL: ACCOUNT MANAGEMENT ====================
@Composable
fun AdminAccountsModal(
    viewModel: MainViewModel,
    onClose: () -> Unit
) {
    val newUsername by viewModel.newUsername.collectAsState()
    val newPassword by viewModel.newPassword.collectAsState()
    val newConfirmPassword by viewModel.newConfirmPassword.collectAsState()
    val adminError by viewModel.adminError.collectAsState()
    val adminSuccess by viewModel.adminSuccess.collectAsState()

    val allUsers by viewModel.allUsers.collectAsState()

    var newPassVisible by remember { mutableStateOf(false) }

    val context = LocalContext.current

    Dialog(onDismissRequest = onClose) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, Color(0xFF44474F), RoundedCornerShape(16.dp))
                .background(CyberSurface)
                .padding(20.dp)
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.ManageAccounts,
                        contentDescription = null,
                        tint = CyberGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "QUẢN LÝ TÀI KHOẢN",
                        color = CyberGold,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF2C1616))
                            .border(1.dp, Color(0xFFC83232).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .clickable { onClose() }
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = "Đóng",
                            color = Color(0xFFFF8080),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                HorizontalDivider(color = Color(0xFF44474F).copy(alpha = 0.5f), modifier = Modifier.fillMaxWidth())

                // Add Member Section
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(CyberBg)
                        .border(1.dp, Color(0xFF44474F).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "➕ TẠO TÀI KHOẢN MỚI",
                        color = CyberGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    // Form Fields
                    // 1. Username
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF16181D))
                            .border(1.dp, Color(0xFF44474F).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color(0xFF20232A))
                        ) {
                            Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                        }
                        TextField(
                            value = newUsername,
                            onValueChange = { viewModel.newUsername.value = it },
                            placeholder = { Text("Tên đăng nhập", color = TextSecondary.copy(alpha = 0.4f), fontSize = 13.sp) },
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                disabledContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            textStyle = TextStyle(color = TextPrimary, fontSize = 14.sp),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // 2. Password
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF16181D))
                            .border(1.dp, Color(0xFF44474F).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color(0xFF20232A))
                        ) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                        }
                        TextField(
                            value = newPassword,
                            onValueChange = { viewModel.newPassword.value = it },
                            placeholder = { Text("Mật khẩu", color = TextSecondary.copy(alpha = 0.4f), fontSize = 13.sp) },
                            singleLine = true,
                            visualTransformation = if (newPassVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                disabledContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            textStyle = TextStyle(color = TextPrimary, fontSize = 14.sp),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // 3. Confirm Password
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF16181D))
                            .border(1.dp, Color(0xFF44474F).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color(0xFF20232A))
                        ) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                        }
                        TextField(
                            value = newConfirmPassword,
                            onValueChange = { viewModel.newConfirmPassword.value = it },
                            placeholder = { Text("Xác nhận mật khẩu", color = TextSecondary.copy(alpha = 0.4f), fontSize = 13.sp) },
                            singleLine = true,
                            visualTransformation = if (newPassVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                disabledContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            textStyle = TextStyle(color = TextPrimary, fontSize = 14.sp),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Success or Error Feedback
                    if (adminError != null) {
                        Text(adminError ?: "", color = Color(0xFFFF6060), fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    }
                    if (adminSuccess != null) {
                        Text(adminSuccess ?: "", color = CyberSuccess, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    }

                    // Create Button
                    Button(
                        onClick = {
                            viewModel.createMember()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5A3D00)),
                        border = BorderStroke(1.dp, CyberGold),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                    ) {
                        Text("TẠO TÀI KHOẢN", color = CyberGold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    }
                }

                // Users list
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "📋 DANH SÁCH TÀI KHOẢN",
                        color = Color(0xFF80D8FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(allUsers) { user ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (user.isKicked) Color(0xFF2C1616) else CyberBg
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (user.isKicked) Color(0xFFC83232).copy(alpha = 0.4f) else Color(0xFF44474F).copy(alpha = 0.5f),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Avatar circle
                                val avColor = if (user.isSystemAdmin) CyberGold else (if (user.isKicked) Color(0xFFFF6060) else CyberPrimary)
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(RoundedCornerShape(50))
                                        .border(1.5.dp, avColor, RoundedCornerShape(50))
                                ) {
                                    Icon(
                                        imageVector = if (user.isSystemAdmin) Icons.Default.Star else (if (user.isKicked) Icons.Default.PersonOff else Icons.Default.Person),
                                        contentDescription = null,
                                        tint = avColor,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                // Username info
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = user.username,
                                        color = if (user.isKicked) Color(0xFFFFAAAA) else TextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        textDecoration = if (user.isKicked) TextDecoration.LineThrough else TextDecoration.None
                                    )
                                    Text(
                                        text = if (user.isSystemAdmin) "ADMIN" else (if (user.isKicked) "BỊ KHOÁ" else "MEMBER"),
                                        color = avColor.copy(alpha = 0.8f),
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                // Actions Group
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (!user.isSystemAdmin) {
                                        // Lock/Unlock Button
                                        Box(
                                            contentAlignment = Alignment.Center,
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .border(
                                                    1.dp,
                                                    if (user.isKicked) CyberSuccess.copy(alpha = 0.5f) else CyberGold.copy(alpha = 0.5f),
                                                    RoundedCornerShape(6.dp)
                                                )
                                                .background(
                                                    if (user.isKicked) Color(0xFF003C14).copy(alpha = 0.25f) else Color(0xFF3C1F00).copy(alpha = 0.25f)
                                                )
                                                .clickable {
                                                    viewModel.toggleKickedStatus(user)
                                                }
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = if (user.isKicked) "MỞ KHOÁ" else "KHOÁ",
                                                color = if (user.isKicked) CyberSuccess else CyberGold,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        // Delete Button
                                        Box(
                                            contentAlignment = Alignment.Center,
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .border(1.dp, Color(0xFFC83232).copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                                .background(Color(0xFF500000).copy(alpha = 0.25f))
                                                .clickable {
                                                    viewModel.deleteUser(user)
                                                    Toast
                                                        .makeText(context, "Đã xoá tài khoản \"${user.username}\"!", Toast.LENGTH_SHORT)
                                                        .show()
                                                }
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = "XOÁ",
                                                color = Color(0xFFFF7070),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
