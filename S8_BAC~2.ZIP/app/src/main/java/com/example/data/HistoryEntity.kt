package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val username: String,
    val lobby: String,
    val tableNum: String,
    val playerScore: Int,
    val bankerScore: Int,
    val totalScore: Int,
    val predictedResult: String, // "NHÀ CON", "NHÀ CÁI", "HÒA"
    val probPlayer: Int,
    val probBanker: Int,
    val probTie: Int,
    val timestamp: Long = System.currentTimeMillis()
)
