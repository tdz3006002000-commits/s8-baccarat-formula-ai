package com.example.data

import kotlinx.coroutines.flow.Flow

class Repository(private val db: AppDatabase) {
    private val userDao = db.userDao()
    private val historyDao = db.historyDao()

    val allUsersFlow: Flow<List<UserEntity>> = userDao.getAllUsersFlow()

    fun getHistoryFlow(username: String): Flow<List<HistoryEntity>> = 
        historyDao.getHistoryForUserFlow(username)

    suspend fun getUserByUsername(username: String): UserEntity? = 
        userDao.getUserByUsername(username)

    suspend fun insertUser(user: UserEntity) = 
        userDao.insertUser(user)

    suspend fun deleteUser(user: UserEntity) = 
        userDao.deleteUser(user)

    suspend fun updateUserKickedStatus(username: String, isKicked: Boolean) = 
        userDao.updateUserKickedStatus(username, isKicked)

    suspend fun insertHistory(history: HistoryEntity) = 
        historyDao.insertHistory(history)

    suspend fun clearHistory(username: String) = 
        historyDao.clearHistoryForUser(username)

    suspend fun seedAdmin() {
        val adminUser = "aqu2005harry"
        val existing = userDao.getUserByUsername(adminUser)
        if (existing == null) {
            userDao.insertUser(
                UserEntity(
                    username = adminUser,
                    password = "300600pt",
                    isKicked = false,
                    isSystemAdmin = true
                )
            )
        }
    }
}
