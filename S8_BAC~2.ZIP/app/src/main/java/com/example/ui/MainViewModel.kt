package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

data class PredictionResult(
    val p: Int,
    val b: Int,
    val t: Int,
    val result: String
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: Repository = Repository(AppDatabase.getDatabase(application))

    // --- State Flow ---
    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    private val _lobby = MutableStateFlow("SẢNH - SEXY")
    val lobby: StateFlow<String> = _lobby.asStateFlow()

    private val _tableNum = MutableStateFlow("C01")
    val tableNum: StateFlow<String> = _tableNum.asStateFlow()

    val playerScore = MutableStateFlow("")
    val bankerScore = MutableStateFlow("")

    private val _isComputing = MutableStateFlow(false)
    val isComputing: StateFlow<Boolean> = _isComputing.asStateFlow()

    private val _computingMessage = MutableStateFlow("")
    val computingMessage: StateFlow<String> = _computingMessage.asStateFlow()

    private val _predictionResult = MutableStateFlow<PredictionResult?>(null)
    val predictionResult: StateFlow<PredictionResult?> = _predictionResult.asStateFlow()

    private val _systemClock = MutableStateFlow("--:--:--")
    val systemClock: StateFlow<String> = _systemClock.asStateFlow()

    private val _waveformHeights = MutableStateFlow<List<Float>>(List(20) { 0.2f })
    val waveformHeights: StateFlow<List<Float>> = _waveformHeights.asStateFlow()

    // Login/Admin states
    val loginUsername = MutableStateFlow("")
    val loginPassword = MutableStateFlow("")
    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    // Add member states
    val newUsername = MutableStateFlow("")
    val newPassword = MutableStateFlow("")
    val newConfirmPassword = MutableStateFlow("")
    private val _adminError = MutableStateFlow<String?>(null)
    val adminError: StateFlow<String?> = _adminError.asStateFlow()
    private val _adminSuccess = MutableStateFlow<String?>(null)
    val adminSuccess: StateFlow<String?> = _adminSuccess.asStateFlow()

    // Members list flow
    val allUsers: StateFlow<List<UserEntity>> = repository.allUsersFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // History flow for currently logged-in user
    val historyList: StateFlow<List<HistoryEntity>> = _currentUser
        .flatMapLatest { user ->
            if (user != null) {
                repository.getHistoryFlow(user.username)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Signal monitor counts
    private val _pCount = MutableStateFlow(0)
    val pCount: StateFlow<Int> = _pCount.asStateFlow()

    private val _bCount = MutableStateFlow(0)
    val bCount: StateFlow<Int> = _bCount.asStateFlow()

    private val _tCount = MutableStateFlow(0)
    val tCount: StateFlow<Int> = _tCount.asStateFlow()

    // Live signal monitor frequencies (synced with prediction or resting at average)
    private val _sigFreqP = MutableStateFlow("—")
    val sigFreqP: StateFlow<String> = _sigFreqP.asStateFlow()

    private val _sigFreqT = MutableStateFlow("—")
    val sigFreqT: StateFlow<String> = _sigFreqT.asStateFlow()

    private val _sigFreqB = MutableStateFlow("—")
    val sigFreqB: StateFlow<String> = _sigFreqB.asStateFlow()

    init {
        viewModelScope.launch {
            repository.seedAdmin()
        }
        startClock()
        startWaveformAnimation()
    }

    // --- Actions ---
    fun setLobby(newLobby: String) {
        _lobby.value = newLobby
    }

    fun setTableNum(newTable: String) {
        _tableNum.value = newTable
    }

    private fun startClock() {
        viewModelScope.launch {
            val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            while (true) {
                _systemClock.value = sdf.format(Date())
                delay(1000)
            }
        }
    }

    private fun startWaveformAnimation() {
        viewModelScope.launch {
            val random = java.util.Random()
            while (true) {
                _waveformHeights.value = List(20) { 0.1f + random.nextFloat() * 0.9f }
                delay(180)
            }
        }
    }

    fun doLogin(onSuccess: () -> Unit) {
        _loginError.value = null
        val username = loginUsername.value.trim()
        val password = loginPassword.value

        if (username.isEmpty() || password.isEmpty()) {
            _loginError.value = "Vui lòng nhập đầy đủ thông tin!"
            return
        }

        viewModelScope.launch {
            val user = repository.getUserByUsername(username)
            if (user != null) {
                if (user.password == password) {
                    if (user.isKicked) {
                        _loginError.value = "⛔ Tài khoản đã bị khoá! Liên hệ admin để mở lại."
                    } else {
                        _currentUser.value = user
                        _pCount.value = 0
                        _bCount.value = 0
                        _tCount.value = 0
                        _sigFreqP.value = "—"
                        _sigFreqT.value = "—"
                        _sigFreqB.value = "—"
                        onSuccess()
                    }
                } else {
                    _loginError.value = "Tên đăng nhập hoặc mật khẩu không đúng!"
                }
            } else {
                _loginError.value = "Tên đăng nhập hoặc mật khẩu không đúng!"
            }
        }
    }

    fun doLogout(onSuccess: () -> Unit) {
        _currentUser.value = null
        loginUsername.value = ""
        loginPassword.value = ""
        _predictionResult.value = null
        clearInputFields()
        onSuccess()
    }

    fun clearInputFields() {
        playerScore.value = ""
        bankerScore.value = ""
    }

    fun calculate() {
        val pScoreStr = playerScore.value.trim()
        val bScoreStr = bankerScore.value.trim()

        val pScore = pScoreStr.toIntOrNull()
        val bScore = bScoreStr.toIntOrNull()

        if (pScore == null || bScore == null || pScore !in 0..9 || bScore !in 0..9) {
            // Setting error is handled on UI
            return
        }

        viewModelScope.launch {
            _isComputing.value = true
            val statusMsgs = listOf(
                "KHỞI TẠO HỆ THỐNG AI...",
                "PHÂN TÍCH DỮ LIỆU ĐẦU VÀO...",
                "TÍNH TOÁN MA TRẬN XÁC SUẤT...",
                "ÁP DỤNG CÔNG THỨC S8...",
                "XỬ LÝ KẾT QUẢ CUỐI CÙNG..."
            )

            for (msg in statusMsgs) {
                _computingMessage.value = msg
                delay(320)
            }

            _isComputing.value = false

            // Process calculation result
            val result = genProbs()
            _predictionResult.value = result

            // Update stats
            when (result.result) {
                "NHÀ CON" -> _pCount.value += 1
                "NHÀ CÁI" -> _bCount.value += 1
                else -> _tCount.value += 1
            }

            // Sync signal monitor frequencies
            _sigFreqP.value = "${result.p}%"
            _sigFreqT.value = "${result.t}%"
            _sigFreqB.value = "${result.b}%"

            // Save history
            val heSo = (4..6).random()
            val totalScore = (pScore + bScore) * heSo
            val history = HistoryEntity(
                username = _currentUser.value?.username ?: "UNKNOWN",
                lobby = _lobby.value,
                tableNum = _tableNum.value,
                playerScore = pScore,
                bankerScore = bScore,
                totalScore = totalScore,
                predictedResult = result.result,
                probPlayer = result.p,
                probBanker = result.b,
                probTie = result.t
            )
            repository.insertHistory(history)

            // Clear inputs
            clearInputFields()
        }
    }

    private fun genProbs(): PredictionResult {
        val random = java.util.Random()
        var p: Int
        var b: Int
        var t: Int
        val resultKey: String

        if (random.nextDouble() < 0.05) {
            // HÒA wins (5%)
            t = random.nextInt(58 - 38 + 1) + 38 // 38 to 58
            val rem = 100 - t
            var pSlice: Int
            do {
                pSlice = random.nextInt((rem - 5) - 5 + 1) + 5
            } while (pSlice == rem - pSlice)
            p = pSlice
            b = rem - p
            resultKey = "tie"
        } else {
            // PLAYER or BANKER wins (95%)
            t = random.nextInt(10 - 2 + 1) + 2 // 2 to 10
            val rem = 100 - t
            var w = random.nextInt(85 - 55 + 1) + 55 // 55 to 85
            var l = rem - w

            if (l < 6) {
                w = rem - 6
                l = 6
            }
            if (w <= l) {
                w = l + random.nextInt(8 - 2 + 1) + 2
                l = rem - w
                if (l < 4) {
                    l = 4
                    w = rem - l
                }
            }

            if (random.nextDouble() < 0.5) {
                p = w
                b = l
                resultKey = "player"
            } else {
                b = w
                p = l
                resultKey = "banker"
            }
        }

        // Ensure total = 100
        val total = p + b + t
        if (total != 100) {
            b += (100 - total)
        }

        // Absolute inequality
        if (p == b) {
            p += 1
            b -= 1
        }

        val result = when (resultKey) {
            "tie" -> "HÒA"
            "player" -> "NHÀ CON"
            else -> "NHÀ CÁI"
        }

        return PredictionResult(p = p, b = b, t = t, result = result)
    }

    fun clearHistory() {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            repository.clearHistory(user.username)
            _predictionResult.value = null
            _pCount.value = 0
            _bCount.value = 0
            _tCount.value = 0
            _sigFreqP.value = "—"
            _sigFreqT.value = "—"
            _sigFreqB.value = "—"
        }
    }

    // --- Admin Panel Actions ---
    fun createMember() {
        _adminError.value = null
        _adminSuccess.value = null
        val u = newUsername.value.trim()
        val p = newPassword.value
        val p2 = newConfirmPassword.value

        if (u.isEmpty() || p.isEmpty() || p2.isEmpty()) {
            _adminError.value = "Vui lòng điền đầy đủ thông tin!"
            return
        }
        if (p != p2) {
            _adminError.value = "Mật khẩu xác nhận không khớp!"
            return
        }
        if (p.length < 6) {
            _adminError.value = "Mật khẩu phải có ít nhất 6 ký tự!"
            return
        }

        viewModelScope.launch {
            // Check if user exists
            val existing = repository.getUserByUsername(u)
            if (existing != null || u.lowercase() == "aqu2005harry") {
                _adminError.value = "Tên đăng nhập đã tồn tại!"
                return@launch
            }

            val newUser = UserEntity(
                username = u,
                password = p,
                isKicked = false,
                isSystemAdmin = false
            )
            repository.insertUser(newUser)
            _adminSuccess.value = "✔ Đã tạo tài khoản \"$u\" thành công!"
            newUsername.value = ""
            newPassword.value = ""
            newConfirmPassword.value = ""
        }
    }

    fun toggleKickedStatus(user: UserEntity) {
        if (user.isSystemAdmin) return
        viewModelScope.launch {
            repository.updateUserKickedStatus(user.username, !user.isKicked)
        }
    }

    fun deleteUser(user: UserEntity) {
        if (user.isSystemAdmin) return
        viewModelScope.launch {
            repository.deleteUser(user)
        }
    }
}
