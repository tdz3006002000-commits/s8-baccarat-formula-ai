package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBg = Color(0xFF010810)
val CyberSurface = Color(0xFF010C1E)
val CyberCardBg = Color(0xFF040F24)
val CyberPrimary = Color(0xFF00E5FF) // Main cyan accent
val CyberAccent = Color(0xFFFF6644)  // Banker color (cam đỏ)
val CyberSuccess = Color(0xFF44CC88) // Tie color (xanh lá)
val CyberGold = Color(0xFFFFC107)    // Admin/Gold
val CyberBlue = Color(0xFF4499FF)    // Player color (xanh dương)
val CyberError = Color(0xFFFF5555)   // Error color

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB0D8FF)
val TextMuted = Color(0xFFCCE8F4)

// Classic values
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)


